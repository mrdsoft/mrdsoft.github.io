const INITIAL_STATE = STORAGE = {
  appLoads: 0,
  vpnOn: false,
  isConnecting: false,
  country: "CA",
  prevCountry: null,
  uid: null,
  settings: {
    disableWebRTC: true,
    skipLocal: false,
    collectTechnical: null,
    collectAnalytics: null,
  },
  locations: [],
  serviceStatusArray: [],
  
  extensionConflict: false,
}