// LEGACY Workaround for Firefox Android 68 missing setBadgeBackgroundColor function

if (typeof chrome.browserAction.setBadgeBackgroundColor !== 'function') {
  chrome.browserAction.setBadgeBackgroundColor = function () {};
}

if (typeof chrome.browserAction.setBadgeBackgroundColor !== 'function') {
  chrome.browserAction.setBadgeText = function () {};
}

if (typeof chrome.browserAction.setIcon !== 'function') {
  chrome.browserAction.setIcon = function () {};
}
